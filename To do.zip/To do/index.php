<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TODO-LIST</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>

<body>
    <?php include "header.php"; ?>
    <?php include "contenu.php"; ?>
</body>

</html>