<header>
    <nav>
        <img src='./assets/img/To do.png' class="logo" alt="Logo Robbie Lens">
        <div class="liens">
            <a href="index.php">Home</a>
            <a href="index.php?val=list">To do List</a>
            <a href="index.php?val=task">Task form</a>
        </div>
    </nav>
</header>
<br />